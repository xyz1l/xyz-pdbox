fx_version 'cerulean'
game 'gta5'

name 'xyz-pd-box'
description 'simple leo pdbox (nsdev) https://discord.com/invite/2QFxyF6nag'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
}

client_scripts {
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}

dependencies {
    'qbx_core',
    'ox_lib',
    'ox_inventory',
}
