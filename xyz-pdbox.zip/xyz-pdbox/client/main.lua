

local resourceName = GetCurrentResourceName()
local function getEventName(event)
    return ('%s:%s'):format(resourceName, event)
end

RegisterNetEvent(getEventName('client:notify'), function(msg, notifType)
    lib.notify({ title = 'PD Box', description = msg, type = notifType or 'inform' })
end)

RegisterNetEvent(getEventName('client:useBox'), function()
    print(('[%s] PD Box used via client event!'):format(resourceName))
    TriggerServerEvent(getEventName('server:useBox'))
end)
