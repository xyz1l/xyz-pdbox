Config = {}


Config.BoxItem = GetCurrentResourceName()

Config.AllowedJobs = {
    'police',
    'leo',
    'sheriff',
    'statepolice',
}


Config.RequireOnDuty = true
 

Config.ArmoryItems = {

    -- Sidearms10
    { item = 'WEAPON_STUNGUN',     label = 'Taser',         amount = 1,  grade = 0 },

    -- Ammo
    { item = 'ammo-9',              label = '9mm',            amount = 700, grade = 0 },

    -- Equipment
    { item = 'heavyarmour',               label = 'Body Armor',          amount = 8,  grade = 0 },
    { item = 'handcuffs',           label = 'Handcuffs',           amount = 5,  grade = 0 },
    { item = 'radio',               label = 'Police Radio',        amount = 1,  grade = 0 },
    { item = 'flashlight',          label = 'Flashlight',          amount = 1,  grade = 0 },
    { item = 'WEAPON_NIGHTSTICK',          label = 'Nightstick',          amount = 1,  grade = 0 }, 
    { item = 'police_badge',        label = 'Police Badge',        amount = 1,  grade = 0 },
    { item = 'diving_gear',        label = 'Diving Gear',        amount = 1,  grade = 0 },
    { item = 'diving_fill',        label = 'Diving Fill',        amount = 1,  grade = 0 },
    { item = 'parachute',        label = 'Parachute',        amount = 1,  grade = 0 },
    { item = 'advancedrepairkit',   label = 'Advanced Repair Kit', amount = 2,  grade = 0 }, 
    { item = 'empty_evidence_bag',        label = 'Empty Evidence Bag',        amount = 10,  grade = 0 },
    { item = 'police_mdt',   label = 'Police MDT', amount = 1,  grade = 0 }, 
    { item = 'cuffkeys', label = 'Cuff Keys', amount = 1, grade = 0},


    -- Medical
    { item = 'bandage',             label = 'Bandage',             amount = 50,  grade = 0 },
    { item = 'painkillers',            label = 'Painkillers',       amount = 20,  grade = 0 },
}
