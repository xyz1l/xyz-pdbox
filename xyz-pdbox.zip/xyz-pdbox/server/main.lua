

local resourceName = GetCurrentResourceName()
local function getEventName(event)
    return ('%s:%s'):format(resourceName, event)
end

local QBX = exports['qbx_core']


local function isAuthorized(source)
    local player = QBX:GetPlayer(source)
    if not player then return false, 0 end

    local job = player.PlayerData.job
    if not job then return false, 0 end
    if Config.RequireOnDuty and not job.onduty then return false, 0 end

    for _, allowed in ipairs(Config.AllowedJobs) do
        if job.name == allowed then
            return true, job.grade.level or 0
        end
    end
    return false, 0
end



RegisterNetEvent(getEventName('server:useBox'), function()
    local src = source
    print(('[%s] Item used by source: %s'):format(resourceName, src))
    local allowed, grade = isAuthorized(src)
    print(('[%s] Auth check for source %s: allowed=%s, grade=%s'):format(resourceName, src, allowed, grade))
    if not allowed then
        TriggerClientEvent(getEventName('client:notify'), src, 'Access denied — LEO on-duty only.', 'error')
        return
    end


    local removed = exports['ox_inventory']:RemoveItem(src, Config.BoxItem, 1)
    if not removed then
        return
    end

    local given  = 0
    local denied = 0

    for _, entry in ipairs(Config.ArmoryItems) do
        if grade >= entry.grade then
            local ok = exports['ox_inventory']:AddItem(src, entry.item, entry.amount)
            if ok then given = given + 1 end
        else
            denied = denied + 1
        end
    end

    if given > 0 then
        local msg = ('Armory loaded — %d item(s) added.'):format(given)
        if denied > 0 then
            msg = msg .. (' %d locked by rank.'):format(denied)
        end
        TriggerClientEvent(getEventName('client:notify'), src, msg, 'success')
        print(('[%s] src:%d received %d armory item types'):format(resourceName, src, given))
    else
        TriggerClientEvent(getEventName('client:notify'), src, 'No items available for your rank.', 'inform')
    end
end)

print(('[%s] Ready — listening for item use via NetEvent'):format(resourceName))